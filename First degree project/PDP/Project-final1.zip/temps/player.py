# For players
import random

class player:
    def foo():
        spam=3
