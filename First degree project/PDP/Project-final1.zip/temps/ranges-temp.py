
print(list(range(1,64,16)))
print(1 in [1,2,3])